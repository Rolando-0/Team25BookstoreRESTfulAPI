package com.example.Wishlist.service;

public class Wishlist {
    public Object setId;

    public String getTitle() {
        return null;
    }

    public Object getId() {
        return null;
    }

    public void setId(String id) {
    }
}
